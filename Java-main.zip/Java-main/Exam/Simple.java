package Exam;

public class Simple {
    public void print(){
        System.out.println("Hello World");
    }



    public static void main(String[] args) {
        Simple s1 = new Simple();
        s1.print();
    }
}
