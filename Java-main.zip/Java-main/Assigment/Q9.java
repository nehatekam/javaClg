

public class Q9 {
    public static void main(String[] args) {
        int a = 12;
        int b = 1;
        for(int i=1;i<=a;i++){
            b = b*i;
        }
        System.out.println(b);
    }
    
}
