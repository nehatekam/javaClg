import  java.util.*;
public class Q5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Miles : ");
        double x = sc.nextDouble();
        double y = ( x*1.609);
        System.out.println(y+" kilometer");

    }
    
}
