class ABC{
    public ABC(){
        System.out.println("There is no Argument ");
    }
}
public class Q31 {
    public static void main(String[] args) {
        ABC a = new ABC();
       

    }
}
