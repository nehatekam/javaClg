class A{
    public A(){
        System.out.println("There is no argument");
    }
}
public class Q2 {
    public static void main(String[] args) {
        A a = new A();
    }
}
