public class even {
    public static void main(String[] args) {
        int n = 30;
        for(int i=0;i<=n;i++){
            if(i%2 == 0){
                System.out.print(i+" ");
                continue;
               
               }
               
            }
        }
    }

