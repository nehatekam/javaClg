import Exam.Simple;
public class helloo {

    public static void main(String[] args) {
        Simple s = new Simple();
        s.print();
    }
}
