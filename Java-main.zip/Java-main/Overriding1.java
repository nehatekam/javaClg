class Animal{
    void eat(){
        System.out.println("eating..");
    }
}
public class Overriding1 {
    public static void main(String[] args) {
        
    }
}
