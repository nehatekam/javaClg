public class datatype {
    public static void main(String[] args) {
       
                
                String a = "Welcome To Java Beat";
                Integer b = 2024;
                Double c = 12.2024;
                Float d = 2023.12f;
                Byte e = 123;
                Boolean f = true;
                Short g = 123;
                Long h = 121232L; 
                
                System.out.println("The Type of " + a + " : " + a.getClass().getName());
                System.out.println("The Type of " + b + " : " + b.getClass().getName());
                System.out.println("The Type of " + c + " : " + c.getClass().getName());
                System.out.println("The Type of " + d + " : " + d.getClass().getName());
                System.out.println("The Type of " + e + " : " + e.getClass().getName());
                System.out.println("The Type of " + f + " : " + f.getClass().getName());
                System.out.println("The Type of " + g + " : " + g.getClass().getName());
                System.out.println("The Type of " + h + " : " + h.getClass().getName());
            }
        }
        

    

